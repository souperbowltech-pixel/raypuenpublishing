GEEZY GOOBER BOOK 1: ALL SEVEN QR CODES
Prepared 2 November 2026

WHAT EACH CODE OPENS
--------------------
Geezy_Book1_QR_start_*  ->  https://puenpublishing.com/start   (Secret Scout Club page, registration)
Geezy_Video_v1_QR_*     ->  https://puenpublishing.com/v1      (after Honesty)
Geezy_Video_v2_QR_*     ->  https://puenpublishing.com/v2      (after Orderliness)
Geezy_Video_v3_QR_*     ->  https://puenpublishing.com/v3      (after Caring)
Geezy_Video_v4_QR_*     ->  https://puenpublishing.com/v4      (Gratitude, the last story page)
Geezy_Video_v5_QR_*     ->  https://puenpublishing.com/v5      (the jingle page)
Geezy_Video_v6_QR_*     ->  https://puenpublishing.com/v6      (the welcome film, foot of the opening page)

WHICH FILE TO USE
-----------------
The _PRINT.svg file of each code is vector and stays sharp at any size. Use it.
Use the 2000px PNG only if the layout software cannot place an SVG.

PRINTING REQUIREMENTS
---------------------
1. Keep the white border. It is part of the code. Do not crop it or place art over it.
2. Print each code at least 1.5 inches square, black on white. No colour, no tint.
3. Type the address in ordinary letters under each code, for a phone that will not scan.
4. Print one proof page at final size and scan every code with an ordinary phone
   before the full run. A QR code cannot be corrected once the books are printed.

Every PNG in this folder was decoded after it was made, and each opens its own address.
Error correction is Level H, the highest.
